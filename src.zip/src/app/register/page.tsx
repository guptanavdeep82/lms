"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PublicPageShell } from "@/components/PublicPageShell";
import { GoogleSignInButton } from "@/components/GoogleSignInButton";
import { loginStudent, saveStudentProfile } from "@/lib/student-auth";
import { checkStudentRegistration, fetchStates, registerStudent, type StateOption } from "@/lib/student-registration";
import { OTP_LENGTH, isValidOtp, sendStudentWhatsappOtp, verifyStudentWhatsappOtp } from "@/lib/student-otp";
import { referralToSessionFields, validateReferralCode } from "@/lib/referral";
import type { GoogleStudent } from "@/lib/google-sign-in";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Gift,
  MapPin,
  Phone,
  ShieldCheck,
} from "lucide-react";

const steps = [
  "Continue with Google to use your name and Gmail automatically",
  "Verify your mobile number with a secure OTP",
  "Open your student dashboard with a verified profile",
];

export default function RegisterPage() {
  const router = useRouter();
  const [inviteCode, setInviteCode] = useState("");
  const [pendingStudent, setPendingStudent] = useState<GoogleStudent | null>(null);
  const [mobile, setMobile] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [sendingOtp, setSendingOtp] = useState(false);
  const [verifyingOtp, setVerifyingOtp] = useState(false);
  const [error, setError] = useState("");
  const [states, setStates] = useState<StateOption[]>([]);
  const [stateId, setStateId] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [referralMessage, setReferralMessage] = useState("");
  const [referralDiscountLabel, setReferralDiscountLabel] = useState("");
  const [referralValid, setReferralValid] = useState(false);
  const [validatingReferral, setValidatingReferral] = useState(false);

  const completeLogin = async (student: GoogleStudent, verifiedMobile: string) => {
    const selectedState = states.find((state) => String(state.id) === stateId);
    if (!selectedState) {
      setError("Please select your state.");
      return;
    }

    const normalizedMobile = verifiedMobile.replace(/\D/g, "").slice(-10);

    try {
      const payload = await registerStudent({
        name: student.name,
        email: student.email,
        mobile: normalizedMobile,
        state_id: selectedState.id,
        provider: "google",
        mobile_verified: true,
        referral_code: referralCode.trim() || undefined,
        invite_code: inviteCode || undefined,
      });

      const referral = referralToSessionFields(payload.student || {});

      const profile = saveStudentProfile({
        name: student.name,
        email: student.email,
        mobile: normalizedMobile,
        stateId: selectedState.id,
        stateName: selectedState.name,
        provider: "google",
        mobileVerified: true,
        ...referral,
      });

      loginStudent({
        name: profile.name,
        email: profile.email,
        mobile: profile.mobile,
        stateId: profile.stateId,
        stateName: profile.stateName,
        provider: "google",
        ...referral,
      });

      const params = new URLSearchParams(window.location.search);
      router.push(params.get("redirect") || "/student/dashboard");
    } catch (registerError) {
      const message = registerError instanceof Error ? registerError.message : "Registration failed. Please try again.";
      setError(message);

      if (message.toLowerCase().includes("email is already registered")) {
        window.setTimeout(() => router.push("/login"), 1800);
      }
    }
  };

  const handleGoogleSignup = useCallback(async (student: GoogleStudent) => {
    setError("");

    const registration = await checkStudentRegistration({ email: student.email });
    if (registration.email_exists) {
      setError("Email is already registered. Please login.");
      window.setTimeout(() => router.push("/login"), 1800);
      return;
    }

    setPendingStudent(student);
  }, [router]);

  const checkReferralCode = async () => {
    const code = referralCode.trim();
    if (!code) {
      setReferralValid(false);
      setReferralMessage("");
      setReferralDiscountLabel("");
      return;
    }

    setValidatingReferral(true);
    setReferralMessage("");
    const result = await validateReferralCode(code);
    setValidatingReferral(false);

    if (!result.valid) {
      setReferralValid(false);
      setReferralDiscountLabel("");
      setReferralMessage(result.message);
      return;
    }

    setReferralValid(true);
    setReferralDiscountLabel(result.referral.discount_label);
    setReferralMessage(result.referral.affiliate_name ? `Valid referral code from ${result.referral.affiliate_name}.` : "Referral code is valid.");
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const invite = params.get("invite");
    if (invite) {
      const normalizedInvite = invite.trim().toUpperCase();
      setInviteCode(normalizedInvite);
      setReferralCode(normalizedInvite);
    }
    const ref = params.get("ref");
    if (ref) {
      setReferralCode(ref.toUpperCase());
    }
  }, []);

  useEffect(() => {
    if (!referralCode.trim()) return;
    const timer = window.setTimeout(() => {
      void checkReferralCode();
    }, 400);
    return () => window.clearTimeout(timer);
  }, [referralCode]);

  useEffect(() => {
    fetchStates()
      .then(setStates)
      .catch(() => setStates([]));
  }, []);

  const sendOtp = async () => {
    const normalizedMobile = mobile.replace(/\D/g, "").slice(-10);
    if (!/^[6-9]\d{9}$/.test(normalizedMobile)) {
      setError("Please enter a valid 10 digit mobile number.");
      return;
    }

    const registration = await checkStudentRegistration({ mobile: normalizedMobile });
    if (registration.mobile_exists) {
      setError("This phone number is already registered with another account.");
      return;
    }

    setSendingOtp(true);
    setError("");
    try {
      await sendStudentWhatsappOtp(normalizedMobile);
      setMobile(normalizedMobile);
      setOtp("");
      setOtpSent(true);
    } catch (sendError) {
      setError(sendError instanceof Error ? sendError.message : "Unable to send OTP on WhatsApp.");
    } finally {
      setSendingOtp(false);
    }
  };

  const verifyOtp = async () => {
    if (!pendingStudent) return;
    if (!isValidOtp(otp)) {
      setError(`Please enter the ${OTP_LENGTH} digit OTP sent on WhatsApp.`);
      return;
    }

    setVerifyingOtp(true);
    setError("");
    try {
      await verifyStudentWhatsappOtp(mobile, otp);
      await completeLogin(pendingStudent, mobile);
    } catch (verifyError) {
      setError(verifyError instanceof Error ? verifyError.message : "OTP verification failed.");
    } finally {
      setVerifyingOtp(false);
    }
  };

  return (
    <PublicPageShell className="min-h-screen bg-white text-[#1e1b3a]">
      <section className="mx-auto grid min-h-[calc(100vh-80px)] max-w-7xl items-center gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[540px_1fr] lg:px-8">
        <div className="relative min-h-[520px] overflow-hidden rounded-[34px] border border-[#0957D3]/15 bg-white p-7 shadow-[0_28px_80px_rgba(9, 87, 211,0.12)] sm:p-9">
          <div className="absolute inset-x-0 top-0 h-2 bg-[#0957D3]" />
          <div className="absolute -right-24 -top-20 h-56 w-56 rounded-full bg-[#0957D3]/10 blur-2xl" />
          <div className="absolute -bottom-28 -left-24 h-64 w-64 rounded-full bg-[#0957D3]/6 blur-2xl" />
          <div className="relative z-10">
            {!pendingStudent ? (
              <>
                <div className="inline-flex rounded-full bg-[#0957D3] px-4 py-2 text-xs font-extrabold uppercase tracking-[0.2em] text-white shadow-lg shadow-[#0957D3]/20">Student Registration</div>
                <h1 className="mt-7 text-3xl font-black tracking-[-0.05em] text-[#1e1b3a] sm:text-4xl">Create Account</h1>
                <p className="mt-4 text-[15px] font-semibold leading-7 text-[#64748b]">Sign up with Google to auto-fill your name and email, then verify your mobile number with OTP.</p>

                <div className="mt-8 rounded-[28px] border border-[#0957D3]/15 bg-white p-5 shadow-[0_18px_44px_rgba(9, 87, 211,0.08)]">
                  <div className="flex items-start gap-3">
                    <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#0957D3] text-lg font-black text-white">G</span>
                    <div>
                      <p className="text-sm font-black text-[#1e1b3a]">Signup using Gmail</p>
                      <p className="mt-1 text-xs font-semibold leading-5 text-[#667085]">Your name and email will be fetched from your Google account.</p>
                    </div>
                  </div>
                  <GoogleSignInButton onSuccess={handleGoogleSignup} label="Continue with Google" className="mt-0" />
                </div>

                <div className="mt-7 grid gap-3">
                  {steps.slice(0, 2).map((step) => (
                    <div key={step} className="flex items-center gap-3 rounded-2xl bg-white/62 px-4 py-3 ring-1 ring-[#e6ebf3]">
                      <CheckCircle2 size={18} className="text-[#0957D3]" />
                      <span className="text-sm font-bold text-[#344054]">{step}</span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <>
                <button type="button" onClick={() => { setPendingStudent(null); setOtpSent(false); setOtp(""); setError(""); }} className="mb-5 inline-flex items-center gap-2 text-sm font-extrabold text-[#0957D3]">
                  <ArrowLeft size={16} /> Change Gmail
                </button>
                <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[#0957D3]">Mobile Verification</p>
                <h1 className="mt-2 text-2xl font-extrabold tracking-[-0.04em] text-[#1e1b3a]">Verify Mobile OTP</h1>
                <div className="mt-4 rounded-2xl bg-[#f8fafc] p-4 ring-1 ring-[#dfe5ef]">
                  <p className="text-sm font-bold text-[#111827]">{pendingStudent.name}</p>
                  <p className="mt-1 text-sm font-semibold text-[#667085]">{pendingStudent.email}</p>
                </div>

                <div className="mt-6 grid gap-4">
                  <label className="grid gap-2 text-sm font-extrabold text-[#344054]">
                    Mobile Number
                    <span className="flex h-12 items-center gap-3 rounded-2xl border border-[#dfe5ef] bg-[#f8fafc] px-4 focus-within:border-[#0957D3]">
                      <Phone size={18} className="text-[#7d8799]" />
                      <input value={mobile} onChange={(event) => setMobile(event.target.value)} className="w-full bg-transparent text-sm font-semibold text-[#111827] outline-none placeholder:text-[#98a2b3]" placeholder="10 digit mobile number" />
                    </span>
                  </label>

                  <label className="grid gap-2 text-sm font-extrabold text-[#344054]">
                    State
                    <span className="flex h-12 items-center gap-3 rounded-2xl border border-[#dfe5ef] bg-[#f8fafc] px-4 focus-within:border-[#0957D3]">
                      <MapPin size={18} className="text-[#7d8799]" />
                      <select value={stateId} onChange={(event) => setStateId(event.target.value)} className="w-full bg-transparent text-sm font-semibold text-[#111827] outline-none">
                        <option value="">Select state</option>
                        {states.map((state) => (
                          <option key={state.id} value={state.id}>{state.name}</option>
                        ))}
                      </select>
                    </span>
                  </label>

                  <label className="grid gap-2 text-sm font-extrabold text-[#344054]">
                    Referral Code (Optional)
                    <span className="flex h-12 items-center gap-3 rounded-2xl border border-[#dfe5ef] bg-[#f8fafc] px-4 focus-within:border-[#0957D3]">
                      <Gift size={18} className="text-[#7d8799]" />
                      <input value={referralCode} onChange={(event) => setReferralCode(event.target.value.toUpperCase())} className="w-full bg-transparent text-sm font-semibold uppercase text-[#111827] outline-none placeholder:normal-case placeholder:text-[#98a2b3]" placeholder="Affiliate referral code" />
                    </span>
                  </label>

                  {validatingReferral && <p className="text-xs font-semibold text-[#667085]">Checking referral code...</p>}
                  {!validatingReferral && referralMessage && (
                    <p className={`rounded-2xl px-4 py-3 text-xs font-bold leading-6 ${referralValid ? "bg-[#ecfdf3] text-[#027a48]" : "bg-[#eef3ff] text-[#0E318D]"}`}>
                      {referralMessage}
                      {referralValid && referralDiscountLabel ? ` Discount: ${referralDiscountLabel}` : ""}
                    </p>
                  )}

                  {otpSent && (
                    <label className="grid gap-2 text-sm font-extrabold text-[#344054]">
                      Enter OTP
                      <span className="flex h-12 items-center gap-3 rounded-2xl border border-[#dfe5ef] bg-[#f8fafc] px-4 focus-within:border-[#0957D3]">
                        <ShieldCheck size={18} className="text-[#7d8799]" />
                        <input value={otp} onChange={(event) => setOtp(event.target.value.replace(/\D/g, "").slice(0, OTP_LENGTH))} className="w-full bg-transparent text-sm font-semibold text-[#111827] outline-none placeholder:text-[#98a2b3]" placeholder={`${OTP_LENGTH} digit OTP`} />
                      </span>
                    </label>
                  )}

                  <button type="button" disabled={sendingOtp || verifyingOtp} onClick={() => void (otpSent ? verifyOtp() : sendOtp())} className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-[#0957D3] text-sm font-extrabold text-white shadow-lg shadow-blue-100 disabled:opacity-70">
                    {verifyingOtp ? "Verifying..." : sendingOtp ? "Sending OTP..." : otpSent ? "Verify OTP & Register" : "Send OTP on WhatsApp"} <ArrowRight size={17} />
                  </button>
                </div>
              </>
            )}

            {error && <p className="mt-4 rounded-2xl bg-[#eef3ff] px-4 py-3 text-sm font-bold leading-6 text-[#0E318D]">{error}</p>}

            <p className="mt-6 text-center text-sm font-semibold text-[#667085]">
              Already registered? <Link href="/login" className="font-extrabold text-[#0957D3]">Login here</Link>
            </p>
          </div>
        </div>

        <div className="relative overflow-hidden rounded-[32px] p-7 text-white shadow-[0_24px_70px_rgba(9, 40, 120,0.28)] sm:p-10" style={{ background: "linear-gradient(135deg, #0E318D 0%, #0538A1 52%, #0957D3 100%)" }}>
          <div className="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-white/10" />
          <div className="absolute bottom-0 right-12 hidden h-44 w-44 rounded-t-full border-[24px] border-white/15 lg:block" />
          <div className="relative z-10 max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-bold uppercase tracking-[0.16em] text-white ring-1 ring-white/15">
              <ShieldCheck size={14} /> KR Logics Admission
            </span>
            <h2 className="mt-6 text-[32px] font-extrabold leading-tight tracking-[-0.05em] sm:text-[48px]">
              Signup with Gmail, verify mobile, start learning.
            </h2>
            <p className="mt-5 max-w-xl text-[16px] leading-8 text-white/72">
              Create your verified student profile in three simple steps and start learning with KR Logics.
            </p>
            <div className="mt-8 grid gap-3">
              {steps.map((step) => (
                <div key={step} className="flex items-center gap-3 rounded-2xl bg-white/8 px-4 py-3 ring-1 ring-white/10">
                  <CheckCircle2 size={18} className="text-white" />
                  <span className="text-sm font-bold text-white/84">{step}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </PublicPageShell>
  );
}
