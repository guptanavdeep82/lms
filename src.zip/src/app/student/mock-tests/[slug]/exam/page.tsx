"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import { useParams, useRouter } from "next/navigation";
import { ChevronRight, Clock3, Expand, HelpCircle, Loader2, Pause, Play, UserRound, X } from "lucide-react";
import type { MockAttemptAnswerInput } from "@/lib/mock-attempt-analysis";
import { saveMockResult } from "@/lib/mock-results";
import { getStudentSession, isStudentLoggedIn } from "@/lib/student-auth";
import { mockTestsApiUrl, mockTestSectionExamUrl, type MockQuestion, type MockTestDetailResponse, type MockTestSectionExamResponse } from "@/lib/mock-tests";

export default function DynamicMockExamPage() {
  const router = useRouter();
  const params = useParams<{ slug: string }>();
  const slug = params.slug;
  const [data, setData] = useState<MockTestDetailResponse | null>(null);
  const [sectionMeta, setSectionMeta] = useState<MockTestSectionExamResponse["section"] | null>(null);
  const [activeSectionId, setActiveSectionId] = useState<number | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [questionTimes, setQuestionTimes] = useState<Record<number, number>>({});
  const [visited, setVisited] = useState<Record<number, boolean>>({});
  const [visitOrder, setVisitOrder] = useState<Record<number, number>>({});
  const [reviewMarked, setReviewMarked] = useState<Record<number, boolean>>({});
  const [validationMessage, setValidationMessage] = useState("");
  const [remainingSeconds, setRemainingSeconds] = useState(0);
  const [sectionDurationSeconds, setSectionDurationSeconds] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const visitCounterRef = useRef(0);
  const questionStartedAtRef = useRef(Date.now());
  const student = getStudentSession();

  useEffect(() => {
    const target = `/student/mock-tests/${slug}/exam`;
    if (!isStudentLoggedIn()) {
      router.replace(`/login?redirect=${encodeURIComponent(target)}`);
      return;
    }

    const params = new URLSearchParams(window.location.search);
    if (params.get("examWindow") !== "1" && window.name !== "mockExamWindow") {
      window.location.replace(`${window.location.pathname}?examWindow=1${params.get("section") ? `&section=${encodeURIComponent(params.get("section")!)}` : ""}`);
      return;
    }

    const sectionSlug = params.get("section");
    const email = student?.email;

    const loadExam = async () => {
      if (sectionSlug && email) {
        const response = await fetch(mockTestSectionExamUrl(slug, sectionSlug, email));
        if (!response.ok) {
          router.replace(`/student/mock-tests/${slug}/setup`);
          return;
        }

        const payload = (await response.json()) as MockTestSectionExamResponse;
        if (payload.test.is_locked) {
          router.replace(`/mock-tests/${payload.test.category_slug ?? ""}`);
          return;
        }

        setData({ test: payload.test, questions: payload.questions, sections: payload.progress.sections, sequential_sections: true });
        setSectionMeta(payload.section);
        setActiveSectionId(payload.section.id);
        const sectionSeconds = payload.section.duration_minutes * 60;
        setSectionDurationSeconds(sectionSeconds);
        setRemainingSeconds(sectionSeconds);
        return;
      }

      const response = await fetch(mockTestsApiUrl(slug, email));
      const payload = (await response.json()) as MockTestDetailResponse;
      if (payload.test.is_locked) {
        router.replace(`/mock-tests/${payload.test.category_slug ?? ""}`);
        return;
      }

      if (payload.sequential_sections && (payload.sections?.length ?? 0) > 0) {
        router.replace(`/student/mock-tests/${slug}/setup`);
        return;
      }

      setData(payload);
      setSectionDurationSeconds(0);
      setRemainingSeconds(payload.test.duration_minutes * 60);
    };

    void loadExam();
  }, [router, slug, student?.email]);

  const questions = data?.questions ?? [];
  const question = questions[currentIndex];
  const answeredCount = useMemo(() => Object.keys(answers).length, [answers]);
  const test = data?.test;
  const activeDurationSeconds = sectionMeta ? sectionDurationSeconds : (test?.duration_minutes ?? 0) * 60;
  const timeUtilizedSeconds = Math.max(
    activeDurationSeconds - remainingSeconds,
    Object.values(questionTimes).reduce((sum, value) => sum + value, 0)
  );
  const timerProgressPercent = activeDurationSeconds
    ? Math.min(100, Math.round((timeUtilizedSeconds / activeDurationSeconds) * 100))
    : 0;
  const timerWarning = sectionMeta && remainingSeconds <= 300;

  const accumulateQuestionTime = useCallback((questionId: number) => {
    const elapsed = Math.max(1, Math.floor((Date.now() - questionStartedAtRef.current) / 1000));
    setQuestionTimes((previous) => ({
      ...previous,
      [questionId]: (previous[questionId] || 0) + elapsed,
    }));
    questionStartedAtRef.current = Date.now();
  }, []);

  useEffect(() => {
    if (!question) return;

    questionStartedAtRef.current = Date.now();
    setVisited((previous) => ({ ...previous, [question.id]: true }));
    setVisitOrder((previous) => {
      if (previous[question.id]) return previous;
      visitCounterRef.current += 1;
      return { ...previous, [question.id]: visitCounterRef.current };
    });
  }, [question]);

  const submitTest = useCallback(async () => {
    if (!data || submitting) return;

    setSubmitting(true);

    const finalTimes = { ...questionTimes };
    if (question) {
      const elapsed = Math.max(1, Math.floor((Date.now() - questionStartedAtRef.current) / 1000));
      finalTimes[question.id] = (finalTimes[question.id] || 0) + elapsed;
    }

    const correct = questions.reduce((sum, item) => sum + (answers[item.id] === item.correct_answer ? 1 : 0), 0);
    const score = questions.reduce((sum, item) => {
      const answer = answers[item.id];
      if (!answer) return sum;
      if (answer === item.correct_answer) return sum + item.marks;
      return sum - item.negative_marks;
    }, 0);

    const timeUsed = Math.max(
      activeDurationSeconds - remainingSeconds,
      Object.values(finalTimes).reduce((sum, value) => sum + value, 0)
    );

    const answerPayload: MockAttemptAnswerInput[] = questions.map((item, index) => ({
      question_id: item.id,
      question_number: index + 1,
      selected_answer: answers[item.id] ?? null,
      time_spent_seconds: finalTimes[item.id] ?? 0,
      marked_for_review: reviewMarked[item.id] ?? false,
      visited: visited[item.id] ?? false,
      visit_order: visitOrder[item.id] ?? null,
    }));

    await saveMockResult(
      {
        slug,
        testTitle: sectionMeta ? `${data.test.title} - ${sectionMeta.name}` : data.test.title,
        testType: data.test.test_type,
        sectionId: activeSectionId ?? undefined,
        sectionSlug: sectionMeta?.slug,
        sectionName: sectionMeta?.name,
        total: questions.length,
        answered: answeredCount,
        correct,
        score,
        submittedAt: new Date().toISOString(),
        timeUtilizedSeconds: timeUsed,
        durationSeconds: activeDurationSeconds,
      },
      answerPayload
    );

    if (sectionMeta) {
      router.push(`/student/mock-tests/${slug}/result?section=${encodeURIComponent(sectionMeta.slug)}`);
      return;
    }

    router.push(`/student/mock-tests/${slug}/result`);
  }, [
    accumulateQuestionTime,
    activeDurationSeconds,
    answeredCount,
    answers,
    data,
    question,
    questionTimes,
    questions,
    remainingSeconds,
    reviewMarked,
    router,
    slug,
    submitting,
    visitOrder,
    visited,
    activeSectionId,
    sectionMeta,
  ]);

  useEffect(() => {
    if (!data || isPaused || remainingSeconds <= 0) return;

    const timer = window.setInterval(() => {
      setRemainingSeconds((seconds) => Math.max(seconds - 1, 0));
    }, 1000);

    return () => window.clearInterval(timer);
  }, [data, isPaused, remainingSeconds]);

  useEffect(() => {
    if (data && remainingSeconds === 0 && !submitting) {
      void submitTest();
    }
  }, [data, remainingSeconds, submitTest, submitting]);

  const enterFullscreen = () => {
    document.documentElement.requestFullscreen?.().catch(() => undefined);
  };

  if (!data || !question || !test) {
    return <main className="grid min-h-screen place-items-center bg-white"><Loader2 className="animate-spin text-[#3378b9]" size={34} /></main>;
  }

  const goToNext = (allowSkip = false, markReview = false) => {
    if (!allowSkip && !answers[question.id]) {
      setValidationMessage("Please select an answer before moving next. Use Skip if you want to leave this question.");
      return;
    }

    if (markReview) {
      setReviewMarked((previous) => ({ ...previous, [question.id]: true }));
    }

    accumulateQuestionTime(question.id);
    setValidationMessage("");
    setCurrentIndex((index) => Math.min(index + 1, questions.length - 1));
  };

  const saveAndNext = () => goToNext(false);
  const markReviewAndNext = () => goToNext(false, true);
  const skipAndNext = () => goToNext(true);

  const jumpToQuestion = (index: number) => {
    if (index > currentIndex && !answers[question.id]) {
      setValidationMessage("Please select an answer before moving next. Use Skip if you want to leave this question.");
      return;
    }

    accumulateQuestionTime(question.id);
    setValidationMessage("");
    setCurrentIndex(index);
  };

  const clearResponse = () => {
    setValidationMessage("");
    setAnswers((previous) => {
      const next = { ...previous };
      delete next[question.id];
      return next;
    });
  };

  return (
    <main className="min-h-screen bg-white text-[#111827]" style={{ fontFamily: "Arial, Helvetica, sans-serif" }}>
      <header className="flex min-h-[50px] flex-col gap-2 bg-[#3378b9] px-3 py-2 text-white sm:px-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <Image src="/kr-logics-logo.png" alt="KR Logics logo" width={36} height={36} className="h-9 w-9 rounded-full border border-[#0957D3] object-cover shadow-lg shadow-black/20" />
            <div>
              <h1 className="text-[13px] font-medium sm:text-[14px]">{sectionMeta ? `${test.title} · ${sectionMeta.name}` : test.title}</h1>
              {sectionMeta && (
                <p className="text-[11px] font-semibold text-[#d8ebff]">
                  Pass mark: {sectionMeta.passing_percentage}% · Section timer active
                </p>
              )}
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className={`flex h-9 items-center rounded bg-white px-2 text-xs text-[#1f4f86] sm:text-sm ${timerWarning ? "ring-2 ring-[#ff3950]" : ""}`}>
              {sectionMeta ? "Section Time:" : "Time Left:"}{" "}
              <span className={`ml-2 rounded px-2 py-1 font-mono font-bold ${timerWarning ? "bg-[#ffe4e6] text-[#be123c]" : "bg-[#d8ebff] text-[#174b82]"}`}>
                {formatDuration(remainingSeconds)}
              </span>
            </div>
            <button onClick={() => setIsPaused((value) => !value)} className="flex h-9 min-w-[76px] items-center justify-center gap-1 rounded bg-white px-2 text-sm text-[#2768a5]">
              {isPaused ? <Play size={15} /> : <Pause size={15} />}{isPaused ? "Resume" : "Pause"}
            </button>
            <button onClick={enterFullscreen} className="grid h-9 w-9 place-items-center rounded bg-white text-[#2768a5]"><Expand size={17} /></button>
          </div>
        </div>
        {sectionMeta && activeDurationSeconds > 0 && (
          <div className="flex items-center gap-3 pb-1">
            <div className="h-2 flex-1 overflow-hidden rounded-full bg-[#1f4f86]/40">
              <div
                className={`h-full rounded-full transition-all ${timerWarning ? "bg-[#ff3950]" : "bg-[#6bbd21]"}`}
                style={{ width: `${timerProgressPercent}%` }}
              />
            </div>
            <span className="min-w-[72px] text-right text-[11px] font-bold text-[#d8ebff]">
              {formatDuration(timeUtilizedSeconds)} used
            </span>
          </div>
        )}
      </header>

      <div className="grid min-h-[calc(100vh-50px)] lg:h-[calc(100vh-50px)] lg:grid-cols-[1fr_260px]">
        <section className="grid min-h-[calc(100vh-50px)] grid-rows-[auto_1fr_auto] overflow-hidden lg:min-h-0">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#cfd7df] bg-[#f6f6f6] px-2 py-2 text-sm">
            <span className="font-bold text-[#0f60b5] underline">{question.section_name}</span>
            <select className="rounded border border-[#111827] bg-white px-2 py-1 text-base">
              <option>English</option>
              <option>Hindi</option>
            </select>
          </div>

          <div className="grid grid-rows-[auto_1fr] overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#cfd7df] px-2 py-2 text-sm">
              <span>Q: {currentIndex + 1} / {questions.length}</span>
              <div className="flex flex-wrap items-center gap-2 sm:gap-5">
                <span className="rounded border border-[#cfd7df] px-3 py-1">Qn. Time : <Clock3 size={12} className="inline" /></span>
                <span><b>Marks :</b> <span className="text-[#00a651]">+{question.marks}</span> | <span className="text-[#ff3950]">-{question.negative_marks}</span></span>
              </div>
            </div>

            <div className="grid overflow-auto lg:grid-cols-2 lg:overflow-hidden">
              <div className="border-b border-[#cfd7df] p-3 text-[15px] leading-7 lg:overflow-y-auto lg:border-b-0 lg:border-r lg:text-[18px] lg:leading-8">
                <p className="mb-4 font-bold">{question.question_text}</p>
              </div>

              <div className="p-4 text-[15px] leading-7 lg:overflow-y-auto lg:text-[18px] lg:leading-8">
                <h2 className="mb-3 font-bold">Choose the correct answer.</h2>
                <div className="mt-4 space-y-4">
                  {(Object.entries(question.options) as Array<[keyof MockQuestion["options"], string | null]>).map(([key, option]) => (
                    option ? (
                      <label key={key} className="flex cursor-pointer items-center gap-3">
                        <input
                          type="radio"
                          name={`question-${question.id}`}
                          checked={answers[question.id] === key}
                          onChange={() => {
                            setValidationMessage("");
                            setAnswers((previous) => ({ ...previous, [question.id]: key }));
                          }}
                          className="h-5 w-5"
                        />
                        <span><b>{key}.</b> {option}</span>
                      </label>
                    ) : null
                  ))}
                </div>
              </div>
            </div>
          </div>

          <footer className="flex flex-col items-stretch justify-between gap-3 border-t border-[#cfd7df] bg-[#efefef] px-4 py-3 sm:flex-row sm:items-center">
            <div className="grid gap-3">
              {validationMessage && (
                <div className="rounded-lg border border-[#ffd4a3] bg-[#fff7ed] px-3 py-2 text-xs font-bold text-[#9a3412]">
                  {validationMessage}
                </div>
              )}
              <div className="flex flex-col gap-3 sm:flex-row sm:gap-5">
                <button onClick={markReviewAndNext} className="rounded-lg border border-[#8dc8ff] bg-[#cae7ff] px-4 py-2 text-sm">Mark for review &amp; next</button>
                <button onClick={clearResponse} className="rounded-lg border border-[#8dc8ff] bg-[#cae7ff] px-4 py-2 text-sm">Clear Response</button>
                <button onClick={skipAndNext} className="rounded-lg border border-[#b9bec8] bg-white px-4 py-2 text-sm font-bold text-[#344054]">Skip</button>
              </div>
            </div>
            <button onClick={saveAndNext} className="rounded-lg bg-[#2f78bf] px-5 py-2 text-center text-sm font-bold text-white shadow">
              Save &amp; Next
            </button>
          </footer>
        </section>

        <aside className="grid border-t border-[#cfd7df] bg-[#eef9ff] lg:grid-rows-[50px_88px_1fr_58px] lg:border-l lg:border-t-0">
          <div className="flex items-center gap-3 bg-[#dff5ff] px-4">
            <div className="grid h-10 w-10 place-items-center rounded-full bg-white text-[#607d8b]"><UserRound size={24} /></div>
            <span className="text-sm">{student?.name || "Student"}</span>
          </div>

          <div className="bg-[#f2f2f2] px-4 py-2 text-sm">
            <p className="mb-2 text-right">
              {sectionMeta ? "Section Time:" : "Time Left:"}{" "}
              <b className={`ml-2 rounded px-2 py-1 font-mono ${timerWarning ? "bg-[#ffe4e6] text-[#be123c]" : "bg-white"}`}>
                {formatDuration(remainingSeconds)}
              </b>
            </p>
            <div className="grid grid-cols-1 gap-x-5 gap-y-2 text-xs sm:grid-cols-2">
              <span className="flex items-center gap-2"><b className="grid h-6 w-7 place-items-center rounded bg-[#6bbd21] text-white">{answeredCount}</b> Answered</span>
              <span className="flex items-center gap-2"><b className="grid h-6 w-7 place-items-center rounded bg-[#d83a0c] text-white">{questions.length - answeredCount}</b> Not Answered</span>
              <span className="flex items-center gap-2"><b className="grid h-6 w-7 place-items-center rounded bg-[#e8e8e8] text-[#111]">{questions.length - Object.keys(visited).length}</b> Not Visited</span>
              <span className="flex items-center gap-2"><b className="grid h-6 w-7 place-items-center rounded-full bg-[#7b4ea3] text-white">{Object.values(reviewMarked).filter(Boolean).length}</b> Review</span>
            </div>
          </div>

          <div className="overflow-y-auto p-4">
            <h3 className="mb-4 bg-[#e8e8e8] py-2 text-center text-sm font-bold">{question.section_name}</h3>
            <div className="grid grid-cols-5 gap-2 sm:grid-cols-7 lg:grid-cols-4 lg:gap-3">
              {questions.map((item, index) => (
                <button
                  key={item.id}
                  onClick={() => jumpToQuestion(index)}
                  className={`h-11 rounded border text-sm ${
                    index === currentIndex
                      ? "border-[#174b82] bg-[#3378b9] font-bold text-white"
                      : answers[item.id]
                        ? "border-[#1b7d31] bg-[#6bbd21] font-bold text-white"
                        : "border-[#9d9d9d] bg-gradient-to-b from-white to-[#d9d9d9] text-[#333]"
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            <button className="absolute right-[252px] top-[386px] hidden h-14 w-7 place-items-center rounded-l bg-[#444] text-white xl:grid">
              <ChevronRight size={22} />
            </button>
          </div>

          <div className="flex items-center justify-center border-t border-[#cfd7df] bg-[#efefef] px-4">
            <button onClick={() => void submitTest()} disabled={submitting} className="h-10 w-full rounded bg-[#2f78bf] text-sm font-bold text-white shadow disabled:opacity-60">
              {submitting ? "Submitting..." : sectionMeta ? "Submit Section" : "Submit Test"}
            </button>
          </div>
        </aside>
      </div>

      <div className="pointer-events-none absolute left-1/2 top-[45px] grid h-12 w-12 -translate-x-1/2 place-items-center rounded-full bg-[#3f3f3f] text-white">
        <X size={24} />
      </div>
      <div className="fixed bottom-4 right-4 hidden rounded-full bg-[#3378b9] p-3 text-white shadow-lg md:block">
        <HelpCircle size={20} />
      </div>
    </main>
  );
}

function formatDuration(totalSeconds: number) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return `${String(hours).padStart(2, "0")} : ${String(minutes).padStart(2, "0")} : ${String(seconds).padStart(2, "0")}`;
}
